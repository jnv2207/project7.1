import uuid


def generate_uuid():
    print("\n--- GENERATE UNIQUE IDENTIFIERS (UUID) ---")
    print("Generated UUID:", uuid.uuid4())
    print("UUID version:", uuid.uuid4().version)
