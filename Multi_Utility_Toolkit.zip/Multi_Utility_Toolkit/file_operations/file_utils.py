from pathlib import Path


def show_file_menu():
    while True:
        print("\n--- FILE OPERATIONS (CUSTOM MODULE) ---")
        print("1. Create or overwrite a text file")
        print("2. Read a text file")
        print("3. Append text to a file")
        print("4. Check whether a file exists")
        print("5. Return to main menu")

        choice = input("Enter your choice: ").strip()

        if choice == "1":
            filename = input("Enter file name (example: notes.txt): ").strip()
            content = input("Enter content: ")
            try:
                Path(filename).write_text(content, encoding="utf-8")
                print(f"File '{filename}' created successfully.")
            except OSError as error:
                print("File error:", error)
        elif choice == "2":
            filename = input("Enter file name to read: ").strip()
            path = Path(filename)
            try:
                if path.is_file():
                    print("\n--- FILE CONTENT ---")
                    print(path.read_text(encoding="utf-8"))
                    print("--- END OF FILE ---")
                else:
                    print("File does not exist.")
            except OSError as error:
                print("File error:", error)
        elif choice == "3":
            filename = input("Enter file name: ").strip()
            content = input("Enter text to append: ")
            try:
                with open(filename, "a", encoding="utf-8") as file:
                    file.write(content + "\n")
                print("Content appended successfully.")
            except OSError as error:
                print("File error:", error)
        elif choice == "4":
            filename = input("Enter file name: ").strip()
            print("File exists." if Path(filename).is_file() else "File does not exist.")
        elif choice == "5":
            break
        else:
            print("Invalid choice. Please try again.")
