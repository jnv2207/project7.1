import random
import string


def show_random_menu():
    while True:
        print("\n--- RANDOM DATA GENERATION ---")
        print("1. Generate a random integer")
        print("2. Generate a random floating-point number")
        print("3. Pick a random item from a list")
        print("4. Generate a random password")
        print("5. Return to main menu")

        choice = input("Enter your choice: ").strip()

        if choice == "1":
            try:
                low = int(input("Enter lower limit: "))
                high = int(input("Enter upper limit: "))
                if low > high:
                    print("Lower limit cannot be greater than upper limit.")
                else:
                    print("Random integer:", random.randint(low, high))
            except ValueError:
                print("Please enter valid integers.")
        elif choice == "2":
            try:
                low = float(input("Enter lower limit: "))
                high = float(input("Enter upper limit: "))
                if low > high:
                    print("Lower limit cannot be greater than upper limit.")
                else:
                    print("Random float:", random.uniform(low, high))
            except ValueError:
                print("Please enter valid numbers.")
        elif choice == "3":
            items = input("Enter items separated by commas: ").split(",")
            items = [item.strip() for item in items if item.strip()]
            if items:
                print("Randomly selected item:", random.choice(items))
            else:
                print("No items were entered.")
        elif choice == "4":
            try:
                length = int(input("Enter password length (minimum 4): "))
                if length < 4:
                    print("Password length must be at least 4.")
                else:
                    characters = string.ascii_letters + string.digits + string.punctuation
                    password = "".join(random.choice(characters) for _ in range(length))
                    print("Generated password:", password)
            except ValueError:
                print("Please enter a valid whole number.")
        elif choice == "5":
            break
        else:
            print("Invalid choice. Please try again.")
